# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the terms described in the LICENSE file in
# the root directory of this source tree.

# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the terms described found in the
# LICENSE file in the root directory of this source tree.

# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the BSD-style license found in the
# LICENSE file in the root directory of this source tree.

# Copyright (c) Meta Platforms, Inc. and affiliates.
# This software may be used and distributed in accordance with the terms of the Llama 3 Community License Agreement.
import time
from typing import List, Optional

from custom_tools.base import CustomTool

from dotenv import load_dotenv

from llama_agentic_system.client import execute_with_custom_tools
from llama_agentic_system.event_logger import EventLogger
from llama_agentic_system.utils import get_agent_system_instance

from llama_models.llama3_1.api.datatypes import *  # noqa: F403
from llama_agentic_system.api import *  # noqa: F403

from termcolor import cprint

load_dotenv()


def prompt_to_message(content: str) -> Message:
    return UserMessage(content=content)


# TODO: Until SFT Image fixed, feed Images as Attachments unless they are the most recent message
def convert_image_to_attachment(img):
    dump_fpath = "/tmp/photogen_" + str(time.time()).replace(".", "_") + ".jpeg"
    img.image.save(dump_fpath, "JPEG")
    return Attachment(filepath=dump_fpath, mimetype="image/jpeg")


async def run_main(
    user_messages: List[Message],
    host: str = "localhost",
    port: int = 5000,
    disable_safety: bool = False,
    custom_tools: Optional[List[CustomTool]] = None,
):
    custom_tools = custom_tools or []
    client = await get_agent_system_instance(
        host=host,
        port=port,
        disable_safety=disable_safety,
        custom_tools=custom_tools,
    )
    await client.create_session(__file__)
    while len(user_messages) > 0:
        message = user_messages.pop(0)
        iterator = execute_with_custom_tools(
            client.api,
            client.system_id,
            client.session_id,
            [message],
            custom_tools,
        )
        cprint(f"User> {message.content}", color="blue")
        async for event, log in EventLogger().log(iterator):
            if log is not None:
                log.print()
