july release
