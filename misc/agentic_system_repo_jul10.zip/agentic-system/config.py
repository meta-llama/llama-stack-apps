from typing import Optional

from pydantic import BaseModel


class SamplingConfig(BaseModel):
    max_seq_len: int = 2048
    max_batch_size: int = 4
    temperature: float = 0.6
    top_p: float = 0.9
    max_gen_len: Optional[int] = None


class SafetyConfig(BaseModel):
    prompt_guard_model_dir: str
    unsafe_categories: Optional[str] = None


class Config(BaseModel):
    checkpoint_dir: str
    tokenizer_path: str
    model_parallel_size: int = 1
    sampling: SamplingConfig = SamplingConfig()
    mock_generation: bool = False
    safety: Optional[SafetyConfig] = None
