from typing import Dict, List

import spotipy
from spotipy.oauth2 import SpotifyClientCredentials

from agentic_system.tools.custom import SingleMessageCustomTool, FunctionParamDefinition


class SpotifyTrendingTool(SingleMessageCustomTool):
    """Tool to get trending songs on Spotify"""

    def __init__(self, client_id: str, client_secret: str) -> None:
        self.client_id = client_id
        self.client_secret = client_secret

        auth_manager = SpotifyClientCredentials(
            client_id=self.client_id, client_secret=self.client_secret
        )
        self.sp = spotipy.Spotify(auth_manager=auth_manager)

    def get_name(self) -> str:
        return "spotify_trending_songs"

    def get_description(self) -> str:
        return "Get top trending songs on Spotify"

    def get_params_definition(self) -> Dict[str, FunctionParamDefinition]:
        return {
            "n": FunctionParamDefinition(
                param_type="int",
                description="Number of trending songs to get",
                required=True,
            )
        }

    async def run_impl(self, n: int) -> List[str]:
        # the model sometimes provides n as a string param
        n = int(n)
        # Fetch the top tracks from the Spotify charts
        # Note: '37i9dQZEVXbMDoHDwVN2tF' is the Spotify Chart ID for Global Top 50
        playlist_id = '37i9dQZEVXbMDoHDwVN2tF'
        results = self.sp.playlist_tracks(playlist_id)

        # Extract track information
        top_tracks = []
        for idx, item in enumerate(results['items']):
            track = item['track']
            top_tracks.append(f"{idx+1}. {track['name']} by {', '.join(artist['name'] for artist in track['artists'])}")

        return top_tracks[:n]
