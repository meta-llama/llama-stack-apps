# Copyright (c) Meta Platforms, Inc. and affiliates.
# This software may be used and distributed in accordance with the terms of the Llama 3 Community License Agreement.

from typing import Optional
import fire

from models.llama3 import (
    Image,
    Message,
)
from toolchain.inference import GeneratorArgs, LlamaModelParallelGenerator
from PIL import Image as _PIL_Image


def main(
    ckpt_dir: str,
    tokenizer_path: str,
    temperature: float = 0.6,
    top_p: float = 0.9,
    max_seq_len: int = 512,
    max_batch_size: int = 4,
    model_parallel_size: int = 1,
    max_gen_len: Optional[int] = None,
):
    args = GeneratorArgs(
        ckpt_dir=ckpt_dir,
        tokenizer_path=tokenizer_path,
        mock_generation=False,
        model_parallel_size=model_parallel_size,
        max_seq_len=max_seq_len,
        max_batch_size=max_batch_size,
    )

    with LlamaModelParallelGenerator(args) as generator:
        dialogs = []
        with open("/home/ashwin/local/test_images/dog.jpg", "rb") as f:
            img = _PIL_Image.open(f).convert("RGB")
            dialogs.append(
                [
                    Message(
                        role="user",
                        content=[
                            Image(image=img),
                            "Describe this image in two sentences",
                        ],
                    )
                ]
            )
        with open("/home/ashwin/local/test_images/sunflower.jpg", "rb") as f:
            img2 = _PIL_Image.open(f).convert("RGB")
            dialogs.append(
                [
                    Message(
                        role="user",
                        content=[
                            Image(image=img),
                            Image(image=img2),
                            "Tell me about both of these images in short",
                        ],
                    )
                ]
            )

        # cannot interleave pure text and image prompt in the same batch
        # In a given batch, only support all elemenets with an image
        # or all prompts are pure text
        results = generator.chat_completion(
            dialogs,
            max_gen_len=max_gen_len,
            temperature=temperature,
            top_p=top_p,
        )
        for result in results:
            print(result)
            print("\n====\n")

        dialogs = [[
            Message(
                role="user",
                content="Tell me a joke"
            )
        ]]
        results = generator.chat_completion(
            dialogs,
            max_gen_len=max_gen_len,
            temperature=temperature,
            top_p=top_p,
        )
        for result in results:
            print(result)
            print("\n====\n")


if __name__ == "__main__":
    fire.Fire(main)
