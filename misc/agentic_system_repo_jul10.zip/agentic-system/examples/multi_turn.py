# Copyright (c) Meta Platforms, Inc. and affiliates.
# This software may be used and distributed in accordance with the terms of the Llama 3 Community License Agreement.
import asyncio
import json
import os
import time

import hydra
from agentic_system import (
    AgenticSystem,
    BraveSearchTool,
    CodeInterpreterTool,
    PhotogenTool,
    with_safety,
    WolframAlphaTool,
)
from config import Config
from custom_tools.boiling_point import GetBoilingPointTool
from custom_tools.spotify import SpotifyTrendingTool

from models.llama3 import (
    Attachment,
    Image,
    Message,
)
from toolchain.inference import GeneratorArgs, LlamaModelParallelGenerator

from omegaconf import DictConfig, OmegaConf
from purple_llama.shields import (
    CodeScannerShield,
    LlamaGuardShield,
    PromptGuardShield,
)


def prompt_to_message(content: str) -> Message:
    return Message(role="user", content=content)


def print_message(msg):
    print(f"> {msg.role.capitalize()}: {msg.content}")
    if isinstance(msg.content, Attachment):
        print(f"{msg.content.filepath}")

# TODO: Until SFT Image + photogen fixed, feed Images as Attachments unless they are the most recent message
def convert_image_to_attachment(img):
    dump_fpath = "/tmp/photogen_" + str(time.time()).replace(".", "_") + ".jpeg"
    img.image.save(dump_fpath, "JPEG")
    return Attachment(filepath=dump_fpath, mimetype='image/jpeg')


async def run_main(config: Config, user_messages: list[Message]):
    args = GeneratorArgs(
        ckpt_dir=config.checkpoint_dir,
        tokenizer_path=config.tokenizer_path,
        mock_generation=config.mock_generation,
        model_parallel_size=config.model_parallel_size,
        max_seq_len=config.sampling.max_seq_len,
        max_batch_size=config.sampling.max_batch_size,
    )

    with LlamaModelParallelGenerator(args) as generator:
        safe_tools = [
            WolframAlphaTool(api_key="LKRWWW-J25AKURL7T"),
            BraveSearchTool(api_key="BSAo9hsA-Gr-d0O-QF65WesoYVqKoRO"),
            CodeInterpreterTool(),
            PhotogenTool(
                api_key="1078097093361062%7CHo16EWDKl2HmOHOEa426PBXVQB8",
                model="photorealism",
                dump_dir="/tmp/photogen_dump_" + os.environ["USER"],
            ),
        ]

        custom_tools = [
            # custom tools
            SpotifyTrendingTool(
                client_id="8323c642360743609220ef6a5a36e5a1",
                client_secret="9f69a6dea32044e8b333ca85af1f95f0",
            ),
        ]
        
        agent = AgenticSystem(
            generator=generator,
            tools=safe_tools + custom_tools,
            max_seq_len=config.sampling.max_seq_len,
            input_shields=[],
            output_shields=[],
        )

        chat_so_far = []
        while len(user_messages) > 0:
            # TODO: Until SFT Image + photogen fixed, feed Images as Attachments unless they are the most recent message
            for message in chat_so_far:
                if isinstance(message.content, Image):
                    message.content = convert_image_to_attachment(message.content)
                elif isinstance(message.content, list):
                    for i, x in enumerate(message.content):
                        if isinstance(x, Image):
                            message.content[i] = convert_image_to_attachment(x)
                    
            chat_so_far.append(user_messages.pop(0))
            
            result = await agent.run(
                dialog=chat_so_far,
                temperature=config.sampling.temperature,
                top_p=config.sampling.top_p,
                max_gen_len=config.sampling.max_gen_len,
            )

            msg = result["generation"]
            print_message(msg)

            chat_so_far.append(msg)
