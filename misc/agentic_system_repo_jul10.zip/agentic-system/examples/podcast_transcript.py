# Copyright (c) Meta Platforms, Inc. and affiliates.
# This software may be used and distributed in accordance with the terms of the Llama 3 Community License Agreement.

import asyncio

from multi_turn import run_main, prompt_to_message

import hydra
from config import Config
from omegaconf import DictConfig, OmegaConf

from models.llama3 import (
    Attachment,
    Message,
)

@hydra.main(version_base=None, config_path="config", config_name="dalton")
def main(cfg: DictConfig):
    config = Config(**OmegaConf.to_container(cfg, resolve=True))
    asyncio.run(run_main(
        config,
        [
            Message(
                role="user",
                content=[
                    "Here is a podcast transcript",
                    Attachment(
                        filepath="examples/transcript_shorter.txt",
                        mimetype="text/plain",
                    ),
                ],
            ),
            prompt_to_message("What are the salient points that were discussed ?"),
            prompt_to_message("Was anything related to 'H100' discussed ?"),
            prompt_to_message("While this podcast happened in April, 2024 can you provide an update from the web on what were the key developments that have happened in the last 3 months since then ?"),
            prompt_to_message("Imagine these people meet again in 1 year, what might be some good followups to ask ?"),
        ]
    ))


if __name__ == "__main__":
    main()
