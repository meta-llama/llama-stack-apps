# Copyright (c) Meta Platforms, Inc. and affiliates.
# This software may be used and distributed in accordance with the terms of the Llama 3 Community License Agreement.

import asyncio

from multi_turn import run_main, prompt_to_message

import hydra
from config import Config
from omegaconf import DictConfig, OmegaConf

from models.llama3 import (
    Attachment,
    Message,
)

@hydra.main(version_base=None, config_path="config", config_name="dalton")
def main(cfg: DictConfig):
    config = Config(**OmegaConf.to_container(cfg, resolve=True))

    asyncio.run(run_main(
        config,
        [
            prompt_to_message("Hello"),
            prompt_to_message("What's new?"),
        ]
    ))


if __name__ == "__main__":
    main()
