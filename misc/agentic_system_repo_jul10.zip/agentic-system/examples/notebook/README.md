First install jupyter within your virtualenv:

```
 with-proxy pip3 install jupyter
```

After that you need to install the following file as `~/.jupyter/jupyter_notebook_config.py`:

```
c = get_config()

import socket
c.NotebookApp.ip = socket.gethostname()
# If you want to be able to connect on VPN (not just on lighthouse) select a
# port between 8080 and 8100.
c.NotebookApp.port = 8085
c.NotebookApp.open_browser = False

c.NotebookApp.certfile = '/var/facebook/x509_identities/server.pem'
c.NotebookApp.disable_check_xsrf = True
c.IPKernelApp.ip = '*'
```

Once that is done, start it from the `notebook/` directory (this directory) with: 

```
 with-proxy jupyter notebook
```

and you should get a URL pointing to your devgpu which you can use to navigate.
