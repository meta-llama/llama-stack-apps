# Copyright (c) Meta Platforms, Inc. and affiliates.
# This software may be used and distributed in accordance with the terms of the Llama 3 Community License Agreement.

import asyncio

from multi_turn import run_main, prompt_to_message

import hydra
from config import Config
from omegaconf import DictConfig, OmegaConf

from PIL import Image as _PIL_Image

from models.llama3 import (
    Image,
    Message,
)

@hydra.main(version_base=None, config_path="config", config_name="dalton")
def main(cfg: DictConfig):
    config = Config(**OmegaConf.to_container(cfg, resolve=True))

    with open('examples/pasta.jpeg', 'rb') as f:
        img = _PIL_Image.open(f).convert("RGB")

    asyncio.run(run_main(
        config,
        [
            Message(
                role="user",
                content=[
                    "How can I make this a more balanced meal?",
                    Image(image=img),
                ],
            ),
            prompt_to_message("Can you show me a picture of that new meal?"),
        ]
    ))


if __name__ == "__main__":
    main()
