# Prerequisites

- Mesop requires Python 3.10. Make sure your Conda environment has 3.10+:
    - `conda deactivate && with-proxy conda create -n llagsys10 python=3.10 && conda activate llagsys10`

- This currently assumes your `llama-agent-system` repo is in your home directory (`~`).

# Run

```
mesop examples/mesop_demo/main.py
```

The server runs on port 32123 by default. Access this in your local browser by forwarding the port over SSH:

```
ssh devgpu123.abc -L 32123:localhost:32123
```

# Notes

- It offers hot reload! Split code you don't want reloaded (ex. load model into memory) into separate modules.

# Troubleshooting

```
Mesop Developer Error: Tried to get the state instance for ChatState, but it's not a state class.
Did you forget to decorate your state class ChatState with @stateclass?
```

This happens when conflicting modules are hot reloaded. Restart your Mesop server.


# Documentation

https://google.github.io/mesop/
