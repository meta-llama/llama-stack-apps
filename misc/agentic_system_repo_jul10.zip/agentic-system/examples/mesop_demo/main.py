import sys
import os
from copy import deepcopy

if sys.version_info < (3, 10):
    raise Exception('Demo requires Python 3.10+')

sys.path += [
    f'{os.path.expanduser("~/llama-agent-system")}'
]

from models.llama3 import (
    Attachment,
    Message,
    Image
)


import uuid
import asyncio

from mesop_agent import MESOP_AGENT

import mesop as me
from chat import KEY_TO_MSG, chat, State, _ROLE_ASSISTANT, _ROLE_USER, _MESSAGE_TYPE_TEXT, _MESSAGE_TYPE_IMAGE
from mesop.events import ClickEvent
from mesop.components.uploader.uploader import UploadEvent, UploadedFile

from PIL import Image as _PIL_Image

UPLOADS_DIR = 'examples/mesop_demo/uploads/'

@me.page(
  path="/",
  title="Llama Agent System",
)
def page():
  state = me.state(State)
  chat(transform, title="Llama Agent System", bot_user="Llama Agent", on_attach=on_attach)

def on_attach(e: me.UploadEvent): 
    path = os.path.join(UPLOADS_DIR, e.file.name)
    state = me.state(State)

    if not os.path.isdir(UPLOADS_DIR):
        os.mkdir(UPLOADS_DIR)

    with open(path, 'wb') as f:
        f.write(e.file.read())
        state.pending_attachment_path = path
        state.pending_attachment_mime_type = e.file.mime_type


# For compatibility with Mesop rendering, we store images as Attachments.
# When we send these to the model, we convert only the latest one to Image.
# This is inefficient, but simplifies maintaining the state.
def load_image_attachment(content, loaded_image):
    if loaded_image[0]:
        return content

    if isinstance(content, Attachment) and 'image' in content.mimetype:
        loaded_image[0] = True
        with open(content.filepath, 'rb') as image_file:
            img = _PIL_Image.open(image_file).convert("RGB")
            return Image(image=img)
    elif isinstance(content, list):
        return [load_image_attachment(x, loaded_image) for x in content]
    else:
        return content


def convert_to_model_input_message(history: list[Message]):
    messages = deepcopy([KEY_TO_MSG[msg_uuid] for msg_uuid in history])

    # TODO: Add user ipython "filename = '<filename>'" hint for better code execution

    # TODO: Once SFT Image + photogen fixed, convert the most recent Image even if it's in history.
    messages[-1].content = load_image_attachment(messages[-1].content, [False])

    return messages

def transform(input: str, history: list[Message]):
    state = me.state(State)
    dialog = convert_to_model_input_message(history)

    result = asyncio.run(MESOP_AGENT.run(
        dialog=dialog,
        temperature=0.6,
        top_p=0.9,
        max_gen_len=2048,
    ))

    return Message(role=_ROLE_ASSISTANT, content=result['generation'].content)
