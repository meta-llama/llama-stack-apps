import os
import hydra
from agentic_system import (
    AgenticSystem,
    BraveSearchTool,
    CodeInterpreterTool,
    PhotogenTool,
    with_safety,
    WolframAlphaTool,
)
from config import Config
from custom_tools.boiling_point import GetBoilingPointTool
from custom_tools.spotify import SpotifyTrendingTool

import getpass

from models.llama3 import (
    Attachment,
    Message,
)
from toolchain.inference import GeneratorArgs, LlamaModelParallelGenerator
from agentic_system import (
    AgenticSystem,
    BraveSearchTool,
    CodeInterpreterTool,
    PhotogenTool,
    with_safety,
    WolframAlphaTool,
)

from purple_llama.shields import LlamaGuardShield

from hydra import compose, initialize
from hydra.errors import MissingConfigException
from omegaconf import OmegaConf

initialize(config_path="../config")
user = getpass.getuser()

try:
    config = compose(config_name=user)
except MissingConfigException:
    print(f"No user-specific {user}.yaml, using default")
    config = compose(config_name="default")


args = GeneratorArgs(
    ckpt_dir=config.checkpoint_dir,
    tokenizer_path=config.tokenizer_path,
    mock_generation=config.mock_generation,
    model_parallel_size=config.model_parallel_size,
    max_seq_len=config.sampling.max_seq_len,
    max_batch_size=config.sampling.max_batch_size,
)

GENERATOR = LlamaModelParallelGenerator(args)
GENERATOR.start()

tools = [
    WolframAlphaTool(api_key="LKRWWW-J25AKURL7T"),
    BraveSearchTool(api_key="BSAo9hsA-Gr-d0O-QF65WesoYVqKoRO"),
    CodeInterpreterTool(),
    PhotogenTool(
        api_key="1078097093361062%7CHo16EWDKl2HmOHOEa426PBXVQB8",
        model="photorealism",
        dump_dir="/tmp/photogen_dump_" + os.environ["USER"],
    ),
]

custom_tools = [
    SpotifyTrendingTool(
        client_id="8323c642360743609220ef6a5a36e5a1",
        client_secret="9f69a6dea32044e8b333ca85af1f95f0",
    ),
]

MESOP_AGENT = AgenticSystem(
    generator=GENERATOR,
    tools=tools + custom_tools,
    max_seq_len=config.sampling.max_seq_len,
    input_shields=[],
    output_shields=[],
)



LLAMA_GUARD_SHIELD = LlamaGuardShield.instance(model_dir=config.safety.llama_guard_text_model_dir)

MESOP_AGENT_WITH_LLAMAGUARD = AgenticSystem(
    generator=GENERATOR,
    tools=tools,
    max_seq_len=config.sampling.max_seq_len,
    input_shields=[LLAMA_GUARD_SHIELD],
    output_shields=[LLAMA_GUARD_SHIELD],
)
