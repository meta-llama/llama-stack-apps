import time
from dataclasses import dataclass
from typing import Any, Callable, Generator, Union, Sequence, Literal
import base64
import mesop as me

from mesop.components.uploader.uploader import UploadEvent

from models.llama3 import (
    Attachment,
    Message,
    Image,
    Role
)

import uuid

# HACK: Mesop's state management has issues with serializing more complex types
# like Union (message content) and PIL_Image. To avoid duplicative message types,
# we'll use a global dict to store the messages and just store message keys in state.
KEY_TO_MSG = {}


_MESSAGE_TYPE_TEXT = "text"
_MESSAGE_TYPE_IMAGE = "image"

_ROLE_USER = "user"
_ROLE_ASSISTANT = "assistant"

_COLOR_BACKGROUND = "#f0f4f8"
_COLOR_CHAT_BUBBLE_YOU = "#f2f2f2"
_COLOR_CHAT_BUBBLE_BOT = "#afc0e4"

_DEFAULT_PADDING = me.Padding.all(20)
_DEFAULT_BORDER_SIDE = me.BorderSide(
  width="1px", style="solid", color="#ececec"
)

_LABEL_BUTTON = "send"
_LABEL_BUTTON_IN_PROGRESS = "pending"
_LABEL_INPUT = "Enter your prompt"

_STYLE_APP_CONTAINER = me.Style(
  background=_COLOR_BACKGROUND,
  display="grid",
  height="100vh",
  grid_template_columns="repeat(1, 1fr)",
)
_STYLE_TITLE = me.Style(padding=me.Padding(left=5))
_STYLE_CHAT_BOX = me.Style(
  height="100%",
  overflow_y="scroll",
  padding=_DEFAULT_PADDING,
  margin=me.Margin(bottom=20),
  border_radius="10px",
  border=me.Border(
    left=_DEFAULT_BORDER_SIDE,
    right=_DEFAULT_BORDER_SIDE,
    top=_DEFAULT_BORDER_SIDE,
    bottom=_DEFAULT_BORDER_SIDE,
  ),
)
_STYLE_CHAT_INPUT = me.Style(width="100%")
_STYLE_CHAT_INPUT_BOX = me.Style(
  padding=me.Padding(top=30), display="flex", flex_direction="row"
)
_STYLE_CHAT_BUTTON = me.Style(margin=me.Margin(top=8, left=8))
_STYLE_CHAT_BUBBLE_NAME = me.Style(
  font_weight="bold",
  font_size="13px",
  padding=me.Padding(left=15, right=15, bottom=5),
)
_STYLE_CHAT_BUBBLE_PLAINTEXT = me.Style(margin=me.Margin.symmetric(vertical=15))

@me.stateclass
class State:
  input: str
  output: list[str]
  in_progress: bool = False
  pending_attachment_path: str
  pending_attachment_mime_type: str
  violation_count: int = 0


def _make_style_chat_ui_container() -> me.Style:
  return me.Style(
    display="grid",
    grid_template_columns="repeat(1, 1fr)",
    grid_template_rows="1fr 14fr 1fr",
    margin=me.Margin.symmetric(vertical=0, horizontal="auto"),
    width="min(1024px, 100%)",
    height="100vh",
    background="#fff",
    box_shadow=(
      "0 3px 1px -2px #0003, 0 2px 2px #00000024, 0 1px 5px #0000001f"
    ),
    padding=me.Padding(top=20, left=20, right=20, bottom=20),
  )


def _make_style_chat_bubble_wrapper(role: Role) -> me.Style:
  """Generates styles for chat bubble position.

  Args:
    role: Chat bubble alignment depends on the role
  """
  align_items = "end" if role == _ROLE_USER else "start"
  return me.Style(
    display="flex",
    flex_direction="column",
    align_items=align_items,
  )


def _make_chat_bubble_style(msg: Message) -> me.Style:
  """Generates styles for chat bubble.

  Args:
    role: Chat bubble background color depends on the role
  """
  background = (
    _COLOR_CHAT_BUBBLE_YOU if msg.role == _ROLE_USER else _COLOR_CHAT_BUBBLE_BOT
  )
  return me.Style(
    width="80%" if isinstance(msg.content, str) else None,
    font_size="16px",
    # line_height="1.5",
    background=background,
    border_radius="15px",
    padding=me.Padding(right=10, left=10, bottom=10, top=10),
    margin=me.Margin(bottom=10),
    border=me.Border(
      left=_DEFAULT_BORDER_SIDE,
      right=_DEFAULT_BORDER_SIDE,
      top=_DEFAULT_BORDER_SIDE,
      bottom=_DEFAULT_BORDER_SIDE,
    ),
  )


def on_blur(e: me.InputBlurEvent):
  state = me.state(State)
  state.input = e.value


def render(content: Union[str, Attachment, Image, Sequence[Union[str, Attachment, Image]]]):
  if isinstance(content, str):
    return me.markdown(content)
  elif isinstance(content, Attachment) and "image" in content.mimetype:
    with open(content.filepath, "rb") as f:
      # TODO: Maybe don't need this hack, if we figure out paths?
      image_base64 = base64.b64encode(f.read()).decode('utf-8')
      data_url = f'data:image/png;base64,{image_base64}'
      return me.image(src=data_url, style=me.Style(height=300))
  elif isinstance(content, Attachment):
    return me.markdown(f'```\n{content.filepath}\n```')
  elif isinstance(content, list):
    return [render(subcontent) for subcontent in content]
        
def closed_chat(title: str, bot_user: str, msg: Message):
  state = me.state(State)
  with me.box(style=_STYLE_APP_CONTAINER):
    with me.box(style=_make_style_chat_ui_container()):
      if title:
        me.text(title, type="headline-5", style=_STYLE_TITLE)
      with me.box(style=_STYLE_CHAT_BOX):
        for msg_uuid in state.output:
            msg = KEY_TO_MSG[msg_uuid]
            with me.box(style=_make_style_chat_bubble_wrapper(msg.role)):
              if msg.role == _ROLE_ASSISTANT:
                me.text(bot_user, style=_STYLE_CHAT_BUBBLE_NAME)
              with me.box(style=_make_chat_bubble_style(msg)):
                  render(msg.content)
              
def chat(
  transform: Callable[
    [str, list[Message]], Generator[str, None, None] | str
  ],
  *,
  title: str,
  bot_user: str,
  on_attach: Callable[[UploadEvent], Any]
):
  state = me.state(State)

  def on_click_submit(e: me.ClickEvent):
    yield from submit()

  def on_input_enter(e: me.InputEnterEvent):
    state = me.state(State)
    state.input = e.value
    yield from submit()

  def submit():
    state = me.state(State)
    if state.in_progress or not state.input:
      return
    input = state.input
    state.input = ""
    yield

    output = state.output
    if output is None:
      output = []

    # Parse any pending attachment into the newly sent message and clear it.
    content = [
      input,
      # TODO: user message with ipython
      Attachment(
          filepath=state.pending_attachment_path,
          mimetype=state.pending_attachment_mime_type,
      )
    ] if state.pending_attachment_path is not None and state.pending_attachment_path != "" else input
    state.pending_attachment_path = None
    state.pending_attachment_mime_type = None
      
    msg_uuid = str(uuid.uuid4())
    KEY_TO_MSG[msg_uuid] = Message(role="user", content=content)
    output.append(msg_uuid)
    
    state.in_progress = True
    yield

    me.scroll_into_view(key="scroll-to")
    time.sleep(0.15)
    yield

    start_time = time.time()
    output_message = transform(input, state.output)

    msg_uuid = str(uuid.uuid4())
    KEY_TO_MSG[msg_uuid] = output_message

    output.append(msg_uuid)
    
    state.output = output
    state.in_progress = False
    yield

  with me.box(style=_STYLE_APP_CONTAINER):
    with me.box(style=_make_style_chat_ui_container()):
      if title:
        me.text(title, type="headline-5", style=_STYLE_TITLE)
      with me.box(style=_STYLE_CHAT_BOX):
        for msg_uuid in state.output:
            msg = KEY_TO_MSG[msg_uuid]
            with me.box(style=_make_style_chat_bubble_wrapper(msg.role)):
              if msg.role == _ROLE_ASSISTANT:
                me.text(bot_user, style=_STYLE_CHAT_BUBBLE_NAME)
              with me.box(style=_make_chat_bubble_style(msg)):
                  render(msg.content)

        if state.in_progress:
          with me.box(key="scroll-to", style=me.Style(height=300)):
            pass

      with me.box(style=_STYLE_CHAT_INPUT_BOX):
        with me.box(style=me.Style(flex_grow=1)):
          me.input(
            label=_LABEL_INPUT,
            # Workaround: update key to clear input.
            key=f"{len(state.output)}",
            on_blur=on_blur,
            on_enter=on_input_enter,
            style=_STYLE_CHAT_INPUT,
          )
        # with me.content_button(
        #   color="primary",
        #   type="flat",
        #   disabled=state.in_progress,
        #   on_click=on_attach,
        #   style=_STYLE_CHAT_BUTTON,
        # ):
        #     me.icon("attach_file")
        with me.content_button(
          color="primary",
          type="flat",
          disabled=state.in_progress,
          on_click=on_click_submit,
          style=_STYLE_CHAT_BUTTON,
        ):
          me.icon(
            _LABEL_BUTTON_IN_PROGRESS if state.in_progress else _LABEL_BUTTON
          )
      me.uploader(
          label="Upload",
          on_upload=on_attach,
      )
