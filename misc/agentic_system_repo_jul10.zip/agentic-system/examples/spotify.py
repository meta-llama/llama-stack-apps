# Copyright (c) Meta Platforms, Inc. and affiliates.
# This software may be used and distributed in accordance with the terms of the Llama 3 Community License Agreement.

import asyncio

from multi_turn import run_main, prompt_to_message

import hydra
from config import Config
from omegaconf import DictConfig, OmegaConf

from models.llama3 import (
    Attachment,
    Message,
)

@hydra.main(version_base=None, config_path="config", config_name="dalton")
def main(cfg: DictConfig):
    config = Config(**OmegaConf.to_container(cfg, resolve=True))

    asyncio.run(run_main(
        config,
        [
            Message(
                role="user",
                content=[
                    "Describe this dataset",
                    Attachment(
                        filepath="examples/spotify-small.csv",
                        mimetype="text/csv",
                    ),
                ],
            ),
            prompt_to_message("Can you print a table of the top artists with most songs?"),
            prompt_to_message("What is the most trending Spotify song currently ?"),
            prompt_to_message("What is its all time rank in the provided dataset?"),
            prompt_to_message("Show the top 10 tracks as a scatter plot of their youtube views v/s spotify streams")
        ]
    ))


if __name__ == "__main__":
    main()
