# Copyright (c) Meta Platforms, Inc. and affiliates.
# This software may be used and distributed in accordance with the terms of the Llama 3 Community License Agreement.

import asyncio

from multi_turn import run_main, prompt_to_message

import hydra
from config import Config
from omegaconf import DictConfig, OmegaConf

from models.llama3 import (
    Attachment,
    Message,
)

@hydra.main(version_base=None, config_path="config", config_name="dalton")
def main(cfg: DictConfig):
    config = Config(**OmegaConf.to_container(cfg, resolve=True))

    asyncio.run(run_main(
        config,
        [
            Message(
                role="user",
                content=[
                    "This is a CSV detailing monthly US inflation rates for the last 10 years. Explain its schema.",
                    Attachment(
                        filepath="examples/inflation.csv",
                        mimetype="text/csv",
                    ),
                ],
            ),
            prompt_to_message("Can you summarize yearly?"),
            prompt_to_message("Can you plot this alongside S&P 500 growth for each year with data? Fetch data from Wolfram Alpha"),
        ]
    ))


if __name__ == "__main__":
    main()
