# run from top level dir as
# PYTHONPATH=. python3 scripts/tokenizer_stats.py <TOKENIZER_PATH>

import fire

from models.llama3.tokenizer import Tokenizer


def main(tokenizer_path: str):
    t = Tokenizer(tokenizer_path)
    for k, index in t.special_tokens.items():
        print(f"{k}: {index}")


if __name__ == "__main__":
    fire.Fire(main)
