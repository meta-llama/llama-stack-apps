#!/bin/bash 

set -euo pipefail 
set -x 

cd $(git rev-parse --show-toplevel)

MODEL_CHECKPOINT_DIR=${MODEL_CHECKPOINT_DIR:-/home/ashwin/local/checkpoints/llama3_7b_01_05_2024_torchx_launch_v5-qzn2md}
TOKENIZER_PATH=${TOKENIZER_PATH:-/home/ashwin/local/checkpoints/llama3_7b_01_05_2024_torchx_launch_v5-qzn2md/cl_toplang_128k}
MODEL_PARALLEL_SIZE=${MODEL_PARALLEL_SIZE:-1}

PYTHONPATH=. \
  with-proxy \
  python3 examples/demo.py \
  $MODEL_CHECKPOINT_DIR \
  $TOKENIZER_PATH \
  --model_parallel_size=$MODEL_PARALLEL_SIZE \
  --max_seq_len=2048 \
  --mock_generation=False \
  --disable_safety=True
