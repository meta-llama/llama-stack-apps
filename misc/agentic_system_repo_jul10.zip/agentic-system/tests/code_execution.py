import unittest
from agentic_system import CodeInterpreterTool
from models.llama3.datatypes import Message, Attachment

class TestCodeInterpreter(unittest.IsolatedAsyncioTestCase):
    async def test_matplotlib(self):
        tool = CodeInterpreterTool()
        message = Message(
            role="ipython",
            content="""
import matplotlib.pyplot as plt
import numpy as np

x = np.array([1, 1])
y = np.array([0, 10])

plt.plot(x, y)
plt.title('x = 1')
plt.xlabel('x')
plt.ylabel('y')
plt.grid(True)
plt.axvline(x=1, color='r')
plt.show()
            """,
        )
        ret = await tool.run([message])

        self.assertEqual(len(ret), 1)

        output = ret[0].content
        self.assertIsInstance(output, Attachment)
        self.assertEqual(output.mimetype, "image/png")

    async def test_path_unlink(self):
        tool = CodeInterpreterTool()
        message = Message(
            role="ipython",
            content="""
import os
from pathlib import Path
import tempfile

dpath = Path(os.environ["MPLCONFIGDIR"])
with open(dpath / "test", "w") as f:
    f.write("hello")

Path(dpath / "test").unlink()
print("_OK_")
            """,
        )
        ret = await tool.run([message])

        self.assertEqual(len(ret), 1)

        output = ret[0].content
        self.assertTrue("_OK_" in output)

if __name__ == "__main__":
    unittest.main()
