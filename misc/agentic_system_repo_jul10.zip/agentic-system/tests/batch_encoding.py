import unittest
from pathlib import Path
from models.llama3.datatypes import Message, Image
from models.llama3.tokenizer import Tokenizer, ChatFormat
from PIL import Image as _PIL_Image
from models.llama3.multimodal.model import CrossAttentionTransformer
from models.llama3.args import ModelArgs

IMG_PATH = Path(__file__).parent.parent / "examples/pasta.jpeg"
TOKENIZER_PATH = Path(__file__).parent.parent / "examples/resources/cl_toplang_128k"

import torch
from fairscale.nn.model_parallel.initialize import (
    initialize_model_parallel,
)

import tempfile


def init_distributed() -> None:
    torch.manual_seed(0)
    if not torch.distributed.is_initialized():
        with tempfile.NamedTemporaryFile(delete=False) as f:
            torch.distributed.init_process_group(
                backend="cpu:gloo,cuda:nccl",
                init_method=f"file://{f.name}",
                world_size=1,
                rank=0,
            )
        initialize_model_parallel(1)


class TestImages(unittest.IsolatedAsyncioTestCase):
    async def test_various_image_counts_in_batch_work(self):
        init_distributed()
        torch.set_default_dtype(torch.bfloat16)
        torch.set_default_device("cuda")

        img = _PIL_Image.open(IMG_PATH).convert("RGB")
        chat_format = ChatFormat(Tokenizer(str(TOKENIZER_PATH)))

        dialogs = [
            [
                Message(
                    role="user",
                    content=[
                        "Tell me a joke",
                    ],
                )
            ],
            [
                Message(
                    role="user",
                    content=[
                        Image(image=img),
                        "Describe this image in two sentences",
                    ],
                )
            ],
            [
                Message(
                    role="user",
                    content=[
                        Image(image=img),
                        "Describe this image in two sentences",
                    ],
                ),
                Message(
                    role="user",
                    content=[
                        Image(image=img),
                        "Describe this image in two sentences",
                    ],
                ),
            ],
        ]
        args = ModelArgs(
            vision_chunk_size=448,
            vision_num_cross_attention_layers=4,
            vocab_size=128256,
        )

        with torch.no_grad():
            model_inputs = [chat_format.encode_dialog_prompt(d) for d in dialogs]

            prompt_tokens = [m.tokens for m in model_inputs]
            max_prompt_len = max(len(t) for t in prompt_tokens)
            total_len = min(args.max_seq_len, 512 + max_prompt_len)

            transformer = CrossAttentionTransformer(args).to("cuda")
            info = transformer.compute_vision_tokens_masks(model_inputs, total_len)

            # just check that all tensor shapes worked correctly
            self.assertTrue(info is not None)


if __name__ == "__main__":
    unittest.main()
