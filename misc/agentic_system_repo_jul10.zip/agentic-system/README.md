
# Llama as a System

We should be viewing the Llama model as part of a *system* or as an entity capable of performing "agentic" tasks. By that we mean the following specific capabilities:

- Ability to act as the central planner -- break a task down and perform multi-step reasoning.
- Ability to perceive multimodal inputs -- text, images, files and eventually speech and video in later iterations.
- Ability to use tools
  - built-in: the model has built-in knowledge of tools like search or code interpreter
  - zero-shot: the model can learn to call tools using previously unseen, in-context tool definitions

Additionally, we would like to shift safety evaluation from the model-level to the overall system level. This allows the underlying model to remain broadly steerable and adaptable to use cases which need varying levels of safety protection.

This repository will work in conjunction with other Github repositories:
- underlying model implementation will be in /meta-llama/llama-models/ (under a llama3 directory)
- safety implementations will be in /meta-llama/purple-llama/

See [this document](https://docs.google.com/document/d/1knsVl7hFjBO0ORWTju17VggQxpbJHZ0MqUv8Zh8AsXU/) for more context and discussions.

## Demo

We've built a demo using [Mesop](https://google.github.io/mesop/).

### Prerequisites

1. Set up a Python 3.10+ environment
1. Install Python prerequisites: `pip install -r requirements.txt`
1. Install [bubblewrap](https://github.com/containers/bubblewrap)
    1. devgpu: already installed
    1. Ubuntu: `sudo apt-get install bubblewrap`
1. Grab a checkpoint and set it up in `~/models/mm_llama3_70b_19_06_2024_rlhf_v5`
1. Copy `examples/config/default.yaml` and create a `<your-username>.yaml` file with your checkpoint paths
1. Forward the Mesop port over SSH if you're running the server on a remote machine (ex. devserver):

```
ssh devgpu123.abc -L 32123:localhost:32123
```

### How to run

```
with-proxy mesop examples/mesop_demo/main.py
```

# Other Demos

Mesop is our main demo. For development purposes, we also have Python scripts and Jupyter notebooks:

### Original demo.py

```bash

# if you are not at the top-level directory, go there
cd $(git rev-parse --show-toplevel)

MODEL_CHECKPOINT_DIR=/home/ashwin/local/checkpoints/llama3_7b_01_05_2024_torchx_launch_v5-qzn2md
TOKENIZER_PATH=/home/ashwin/local/checkpoints/llama3_7b_01_05_2024_torchx_launch_v5-qzn2md/cl_toplang_128k

PYTHONPATH=. \
  with-proxy \
  python3 examples/demo.py \
  checkpoint_dir=$MODEL_CHECKPOINT_DIR \
  tokenizer_path=$TOKENIZER_PATH \
  +sampling.max_seq_len=2048 \
  +sampling.mock_generation=False

```

If you want to disable safety, add ` safety=null` to the command line above.

We use Hydra for configuration; the default config is at `examples/config/default.yaml`

### Multimodal (WIP)

```
PYTHONPATH=. python3 ./examples/multimodal_demo.py \
--ckpt_dir /home/hjshah/local/checkpoints/mm_llama3_70b_19_06_2024_rlhf_v5/ \
--tokenizer_path /home/hjshah/local/checkpoints/mm_llama3_70b_19_06_2024_rlhf_v5/cl_toplang_128k \
--model-parallel-size 8
```
