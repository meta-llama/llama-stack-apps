import asyncio
from typing import List

from .base import OnViolationAction, ShieldBase, ShieldResponse
from models.llama3.datatypes import Message


class SafetyException(Exception):
    pass


class ShieldRunnerMixin:

    def __init__(
        self,
        input_shields: List[ShieldBase] = None,
        output_shields: List[ShieldBase] = None
    ):
        self.input_shields = input_shields
        self.output_shields = output_shields

    async def run_shields(self, messages: List[Message], shields: List[ShieldBase]) -> List[ShieldResponse]:
        # some shields like llama-guard require the first message to be a user message
        # since this might be a tool call, first role might not be user
        if len(messages) > 0 and messages[0].role != "user":
            messages[0].role = "user"

        results = await asyncio.gather(*[s.run(messages) for s in shields])
        for shield, r in zip(shields, results):
            if r.is_violation:
                if shield.on_violation_action == OnViolationAction.RAISE:
                    raise SafetyException(r.violation_return_message)
                elif shield.on_violation_action == OnViolationAction.WARN:
                    cprint(f"[Warn]{shield.__class__.__name__} raised a warning", color="red")

        return results
