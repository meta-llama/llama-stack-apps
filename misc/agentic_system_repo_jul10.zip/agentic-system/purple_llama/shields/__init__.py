# supress warnings and spew of logs from hugging face
import transformers

from .base import DummyShield, OnViolationAction, ShieldBase, ShieldResponse, TextShield
from .code_scanner import CodeScannerShield
from .llama_guard import LlamaGuardShield
from .prompt_guard import PromptGuardShield
from .shield_runner import SafetyException, ShieldRunnerMixin

transformers.logging.set_verbosity_error()

import os

os.environ["TOKENIZERS_PARALLELISM"] = "false"

import warnings

warnings.filterwarnings("ignore")
