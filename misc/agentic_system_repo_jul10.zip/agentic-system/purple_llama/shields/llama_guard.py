import re
from termcolor import cprint
from typing import Optional, List
from string import Template
from dataclasses import dataclass
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from .base import ShieldResponse, ShieldBase, OnViolationAction
from models.llama3.datatypes import Message


SAFE_RESPONSE = "safe"
_INSTANCE = None

@dataclass
class SafetyCategory:
    name: str
    description: str

CANNED_RESPONSE_TEXT = "I can't answer that. Can I help with something else?"

CRS_V2_CAT = [
            SafetyCategory(
                "Violent Crimes. ",
                """AI models should not create content that enables, encourages, or excuses the commission of violent crimes. Examples of violent crimes include, but are not limited to:
                - Unlawful violence toward people (ex: terrorism, genocide, murder, hate crimes, child abuse, assault, battery, kidnapping)
                - Unlawful violence toward animals (ex: animal abuse)"""),
            SafetyCategory(
                "Non-Violent Crimes. ",
                """AI models should not create content that enables, encourages, or excuses the commission of non-violent crimes. Examples of non-violent crimes include, but are not limited to:
                - Financial crimes (ex: fraud, scams, money laundering)
                - Property crimes (ex: burglary, robbery, arson, vandalism)
                - Drug crimes (ex: creating or trafficking narcotics)
                - Weapons crimes (ex: producing unlicensed firearms)
                - Cyber crimes (ex: hacking, spyware, malware)"""),
            SafetyCategory(
                "Sex Crimes. ",
                """AI models should not create content that enables, encourages, or excuses the commission of sex crimes. Examples of sex crimes include, but are not limited to:
                - Human trafficking
                - Sexual assault (ex: rape)
                - Sexual harassment (ex: groping)
                - Lewd conduct"""),
            SafetyCategory(
                "Child Exploitation. ",
                "AI models should not create content that depicts child nudity or that enables, encourages, excuses, or depicts the sexual abuse of children."),
            SafetyCategory(
                "Defamation. ",
                "AI models should not create content about a real, living person that is verifiably false and likely to injure the person's reputation."),
            SafetyCategory(
                "Specialized Advice. ",
                "AI models should not create content that contains specialized financial, medical, or legal advice."),
            SafetyCategory(
                "Privacy. ",
                "AI models should not create content that contains sensitive, personal information about private individuals."),
            SafetyCategory(
                "Intellectual Property. ",
                "AI models should not create content that violates the intellectual property rights of third parties."),
            SafetyCategory(
                "Indiscriminate Weapons. ",
                """I models should not create content that enables the creation of weapons of mass destruction. Examples of such weapons include, but are not limited to:
                - Chemical weapons (ex: nerve gas)
                - Biological weapons (ex: anthrax)
                - Radiological weapons (ex: salted bombs)
                - Nuclear weapons (ex: atomic warheads)
                - High-yield explosive weapons (ex: cluster munitions)"""),
            SafetyCategory(
                "Hate. ",
                "AI models should not create content that is hateful toward people on the basis of their protected characteristics (race, color, ethnicity, national origin, disability, religious affiliation, caste, sexual orientation, sex, gender identity and serious disease). AI models should not create content that perpetuates negative stereotypes."),
            SafetyCategory(
                "Self-Harm. ",
                """AI models should not create content that enables, encourages, or excuses acts of intentional self-harm. Examples of such actions include, but are not limited to:
                - Suicide
                - Self-injury (ex: cutting)
                - Disordered eating"""),
            SafetyCategory(
                "Sexual Content. ",
                "AI models should not create depictions of nude adults or content that contains erotic descriptions or explicit depictions of sex acts."),
            SafetyCategory(
                "Elections. ",
                "AI models should not create content that contain factually incorrect information about electoral systems and processes, including in the time, place, or manner of voting in civic elections."),
            SafetyCategory(
                "Code Interpreter Abuse. ",
                """AI models should not create content that attempts to abuse code interpreters. Examples of code interpreter abuse include, but are not limited to:
                - Denial of service attacks
                - Container escapes or privilege escalation."""
            )
          ]
        
PROMPT_TASK = "Task: Check if there is unsafe content in '$agent_type' messages in conversations according our safety policy with the below categories."

SAFETY_CATEGORIES = """

<BEGIN UNSAFE CONTENT CATEGORIES>
$categories
<END UNSAFE CONTENT CATEGORIES>
"""

PROMPT_CONVERSATION = """
<BEGIN CONVERSATION>

$conversations

<END CONVERSATION>
"""


PROMPT_INSTRUCTIONS = """
Provide your safety assessment for ONLY THE LAST $agent_type message in the above conversation:
- First line must read 'safe' or 'unsafe'.
- If unsafe, a second line must include a comma-separated list of violated categories."""


PROMPT_TEMPLATE = Template(f"[INST] {PROMPT_TASK}{SAFETY_CATEGORIES}{PROMPT_CONVERSATION}{PROMPT_INSTRUCTIONS} [/INST]")



class LlamaGuardShield(ShieldBase):

    @staticmethod
    def instance(
        on_violation_action=OnViolationAction.RAISE, model_dir: str = None, config = {}
    ) -> "LlamaGuardShield":
        global _INSTANCE
        if _INSTANCE is None:
            _INSTANCE = LlamaGuardShield(on_violation_action, model_dir, config)
        return _INSTANCE

    def __init__(
        self,
        on_violation_action: OnViolationAction = OnViolationAction.RAISE,
        model_dir: str = None,
        config = {}
        
    ):
        super().__init__(on_violation_action)

        # model_id = "meta-llama/Meta-Llama-Guard-2-8B" HF model_id for llama guard 2
        dtype = torch.bfloat16

        if model_dir is None:
            model_dir = '/home/models/llama_guard_v3/text_hf'        
        
        self.device = "cuda"
        self.config = config
        self.tokenizer = AutoTokenizer.from_pretrained(model_dir)
        self.model = AutoModelForCausalLM.from_pretrained(
            model_dir, torch_dtype=dtype, device_map=self.device
        )

    def check_unsafe_response(self, response: str) -> Optional[str]:
        match = re.match(r"^unsafe\n(.*)$", response)
        if match:
            # extracts the unsafe code
            extracted = match.group(1)
            return extracted

        return None

    def build_prompt(self, messages: List[Message], with_policy: bool = False) -> str:
        
        categories_str = "\n".join([f"S{i+1}: {c.name}" + (f"\n{c.description}" if with_policy else "") for i, c in enumerate(CRS_V2_CAT)])
        conversations_str = "\n\n".join([f"{m.role.capitalize()}: {m.content_as_str()}" for m in messages])


        return PROMPT_TEMPLATE.substitute(agent_type=messages[-1].role.capitalize(), categories=categories_str, conversations=conversations_str)


    async def run(self, messages: List[Message]) -> ShieldResponse:

        if self.config.get("disable_input_shield", False) and messages[-1].role == "user":
            return ShieldResponse(is_violation=False)
        elif self.config.get("disable_output_shield", False) and messages[-1].role == "assistant":
            return ShieldResponse(is_violation=False)
        else:
            text = "\n".join([m.content_as_str() for m in messages])
            cprint(f"Running LlamaGuard shield on {text[:50]}...", color="magenta")

            prompt = self.build_prompt(messages)
            input_text = self.tokenizer([prompt], return_tensors="pt").to(self.device)
            prompt_len = input_text["input_ids"].shape[-1]
            output = self.model.generate(input_ids=input_text["input_ids"], max_new_tokens=100, pad_token_id=0)
            response = self.tokenizer.decode(output[0][prompt_len:], skip_special_tokens=True)
            
            cprint(f"LG prompt{prompt}", color="magenta")

            cprint(f"Llama Guard response {response}", color="magenta")
            
            if response == SAFE_RESPONSE:
                return ShieldResponse(is_violation=False)
            
            unsafe_code = self.check_unsafe_response(response)
            if unsafe_code:
                unsafe_code_list = unsafe_code.split(",")
                return ShieldResponse(is_violation=True, violation_type=unsafe_code, violation_return_message=CANNED_RESPONSE_TEXT, on_violation_action=OnViolationAction.RAISE)

            raise ValueError(f"Unexpected response: {response}")
