from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from typing import Optional, List

from termcolor import cprint

from models.llama3.datatypes import Message


@dataclass
class OnViolationAction(Enum):
    """Action to take when a violation is detected"""
    IGNORE = 0
    WARN = 1
    RAISE = 2


@dataclass(frozen=True, eq=True)
class ShieldResponse:
    is_violation: bool
    violation_type: Optional[str] = None
    violation_return_message: Optional[str] = None
    on_violation_action: Optional[OnViolationAction] = None


class ShieldBase(ABC):

    def __init__(
        self,
        on_violation_action: OnViolationAction = OnViolationAction.RAISE,
    ):
        self.on_violation_action = on_violation_action

    @abstractmethod
    async def run(self, messages: List[Message]) -> ShieldResponse:
        raise NotImplementedError()


# For shields that operate on simple strings
class TextShield(ShieldBase):
    def convert_messages_to_text(self, messages: List[Message]) -> str:
        return "\n".join([m.content for m in messages])

    async def run(self, messages: List[Message]) -> ShieldResponse:
        text = self.convert_messages_to_text(messages)
        return await self.run_impl(text)

    @abstractmethod
    async def run_impl(self, text: str) -> ShieldResponse:
        raise NotImplementedError()


class DummyShield(TextShield):

    async def run_impl(self, text: str) -> ShieldResponse:
        # Dummy return LOW to test e2e
        return ShieldResponse(is_violation=False)
