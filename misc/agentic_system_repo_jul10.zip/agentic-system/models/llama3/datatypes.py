from PIL import Image as _PIL_Image

from dataclasses import dataclass
from typing import Literal, Sequence, Union

Role = Literal["system", "user", "assistant", "ipython"]


@dataclass
class Attachment:
    filepath: str
    mimetype: str


@dataclass
class Image:
    image: _PIL_Image.Image


@dataclass
class Message:
    role: Role
    content: Union[
        str,
        Attachment,
        Image,
        Sequence[Union[str, Attachment, Image]]
    ]
    eot: bool = True
    ipython: bool = False
    is_violation: bool = False

    def content_as_str(self) -> str:
        def _to_str(content: Union[str, Attachment, Image]) -> str:
            if isinstance(content, str):
                return content
            elif isinstance(content, Attachment):
                return f"File: {content.filepath}"
            elif isinstance(content, Image):
                return "Image"
            else:
                raise

        if isinstance(self.content, list):
            return "\n".join(
                [
                    _to_str(c)
                    for c in self.content
                ]
            )
        else:
            return _to_str(self.content)

    def __str__(self):
        return f"{self.role.capitalize()}> {self.content_as_str()}"


Dialog = Sequence[Message]
