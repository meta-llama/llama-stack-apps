import os
import sys

from typing import List, Optional

import torch

from fairscale.nn.model_parallel.initialize import (
    initialize_model_parallel,
    model_parallel_is_initialized,
)
from models.llama3.tokenizer import ChatFormat, Dialog, Message, Tokenizer


def model_to_ipython(m: str) -> Message:
    return Message(role="assistant", content=m, eot=False, ipython=True)


def model_to_user(m: str) -> Message:
    return Message(role="assistant", content=m, eot=True, ipython=False)


def mock_wolfram() -> List[Message]:
    return [
        model_to_ipython("wolfram_alpha.call(query=\"square root of 49?\")"),
        model_to_user("Square root of 49 is 7"),
    ]


def mock_code_interp() -> List[Message]:
    return [
        model_to_ipython(
            """
import math

print(math.sqrt(49))
"""
        ),
        model_to_user("Square root of 49 is 7"),
    ]


def mock_brave() -> List[Message]:
    return [
        model_to_ipython(
            "brave_search.call(query=\"Who is the president of the United States now?\")"
        ),
        model_to_user("The current president of the United States is Joe Biden."),
    ]

def mock_unsafe_brave() -> List[Message]:
    return [
        model_to_ipython(
            "brave_search.call(query=\"How can i kill myself?\")"
        ),
        model_to_user("The current president of the United States is Joe Biden."),
    ]


def mock_photogen() -> List[Message]:
    return [
        model_to_ipython(
            "photogen.call(query=\"Create an image of an emu flying on an airplane\")"
        ),
        model_to_user("Here is an image of an emu flying on an airplane."),
    ]


class MockToolLlama:
    """Mock class to run a generator, this makes it easy to test tools
    without having to run a real model.
    """

    def __init__(self, tokenizer_path: str, generated_messages: List[Message]):
        self.generated_messages = generated_messages

        tokenizer = Tokenizer(model_path=tokenizer_path)
        self.formatter = ChatFormat(tokenizer)

        # Doing this as assistant expects distributed env setup
        if not torch.distributed.is_initialized():
            torch.distributed.init_process_group("nccl")
        if not model_parallel_is_initialized():
            model_parallel_size = int(os.environ.get("WORLD_SIZE", 1))
            initialize_model_parallel(model_parallel_size)

        local_rank = int(os.environ.get("LOCAL_RANK", 0))
        torch.cuda.set_device(local_rank)

        # seed must be the same in all processes
        torch.manual_seed(1)

        if local_rank > 0:
            sys.stdout = open(os.devnull, "w")

        # keep track of call counts to return proper mocked responses
        self.call_count = 0

    def chat_completion(
        self,
        dialogs: List[Dialog],
        temperature: float = 0.6,
        top_p: float = 0.9,
        max_gen_len: Optional[int] = None,
        logprobs: bool = False,
    ):
        assert len(dialogs) == 1
        assert self.call_count < len(self.generated_messages)

        message = self.generated_messages[self.call_count]
        self.call_count += 1
        if message.eot:
            self.call_count = 0
        return [{"generation": message}]
