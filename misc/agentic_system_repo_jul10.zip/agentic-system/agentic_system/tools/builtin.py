import base64
import json
import re
import time

from abc import abstractmethod
from datetime import datetime
from io import BytesIO
from pathlib import Path
from termcolor import cprint
from typing import List, Optional

import requests
from .ipython_tool.code_execution import (
    CodeExecutionContext,
    CodeExecutionRequest,
    CodeExecutor,
    TOOLS_ATTACHMENT_KEY,
    TOOLS_ATTACHMENT_KEY_REGEX,
)
from PIL import Image

from models.llama3.datatypes import Attachment, Message

from .base import BaseTool
from .utils import ToolUtils


def interpret_content_as_attachment(content: str) -> Optional[Attachment]:
    match = re.search(TOOLS_ATTACHMENT_KEY_REGEX, content)
    if match:
        snippet = match.group(1)
        data = json.loads(snippet)
        return Attachment(**data)

    return None


class SingleMessageBuiltinTool(BaseTool):
    async def run(self, messages: List[Message]) -> List[Message]:
        assert len(messages) == 1, f"Expected single message, got {len(messages)}"
        tool_info = ToolUtils.maybe_extract_builtin_tool_call(messages[0].content)
        assert tool_info is not None, "Expected a builtin tool call format"

        _, query = tool_info
        response: str = await self.run_impl(query)

        message = Message(role="ipython", content=response)
        if attachment := interpret_content_as_attachment(response):
            message.content = attachment

        return [message]

    @abstractmethod
    async def run_impl(self, query: str) -> str:
        raise NotImplementedError()


class PhotogenTool(SingleMessageBuiltinTool):

    def __init__(self, api_key: str, model: str, dump_dir: str) -> None:
        self.api_key = api_key
        self.model = model
        self.dump_dir = dump_dir

    def get_name(self) -> str:
        return "photogen"

    async def run_impl(self, query: str) -> str:
        url = "https://graph.facebook.com/v18.0/image_generations"
        params = {
            "model": self.model,
            "access_token": self.api_key,
        }
        headers = {"Content-Type": "application/json"}
        data = {"prompts": [query]}
        response = requests.post(
            url,
            params=params,
            headers=headers,
            json=data
        )
        filtered_response = response.json()
        try:
            dump_dir = self.dump_dir
            if "images" in filtered_response:
                image_data = filtered_response["images"][0]
                im = Image.open(BytesIO(base64.b64decode(image_data)))

                dump_dname = datetime.today().strftime("%Y-%m-%d")
                dump_dpath = Path(dump_dir, dump_dname)
                dump_dpath.mkdir(parents=True, exist_ok=True)

                dump_fname = "photogen_" + str(time.time()).replace(".", "_") + ".png"
                dump_fpath = dump_dpath / dump_fname
                im.save(dump_fpath, "PNG")

                dump_rel_fpath = dump_fpath.relative_to(dump_dir)

                # create output in a format which can be parsed back by our tool execution engine
                info = {
                    "filepath": str(dump_fpath),
                    "mimetype": "image/png",
                }
                return f"{TOOLS_ATTACHMENT_KEY}={json.dumps(info)}"
            else:
                return json.dumps(filtered_response)

        except KeyError:
            return json.dumps(filtered_response)


class BraveSearchTool(SingleMessageBuiltinTool):

    def __init__(self, api_key: str) -> None:
        self.api_key = api_key

    def get_name(self) -> str:
        return "brave_search"

    async def run_impl(self, query: str) -> str:
        url = "https://api.search.brave.com/res/v1/web/search"
        headers = {
            "X-Subscription-Token": self.api_key,
            "Accept-Encoding": "gzip",
            "Accept": "application/json",
        }
        payload = {"q": query}
        response = requests.get(url=url, params=payload, headers=headers)
        return json.dumps(self._clean_brave_response(response.json()))

    def _clean_brave_response(self, search_response, top_k=3):
        query = None
        clean_response = []
        if "query" in search_response:
            if "original" in search_response["query"]:
                query = search_response["query"]["original"]
        if "mixed" in search_response:
            mixed_results = search_response["mixed"]
            for m in mixed_results["main"][:top_k]:
                r_type = m["type"]
                results = search_response[r_type]["results"]
                if r_type == "web":
                    # For web data - add a single output from the search
                    idx = m["index"]
                    selected_keys = [
                        "type",
                        "title",
                        "url",
                        "description",
                        "date",
                        "extra_snippets",
                    ]
                    cleaned = {
                        k: v for k, v in results[idx].items() if k in selected_keys
                    }
                elif r_type == "faq":
                    # For faw data - take a list of all the questions & answers
                    selected_keys = ["type", "question", "answer", "title", "url"]
                    cleaned = []
                    for q in results:
                        cleaned.append(
                            {k: v for k, v in q.items() if k in selected_keys}
                        )
                elif r_type == "infobox":
                    idx = m["index"]
                    selected_keys = [
                        "type",
                        "title",
                        "url",
                        "description",
                        "long_desc",
                    ]
                    cleaned = {
                        k: v for k, v in results[idx].items() if k in selected_keys
                    }
                elif r_type == "videos":
                    selected_keys = [
                        "type",
                        "url",
                        "title",
                        "description",
                        "date",
                    ]
                    cleaned = []
                    for q in results:
                        cleaned.append(
                            {k: v for k, v in q.items() if k in selected_keys}
                        )
                elif r_type == "locations":
                    # For faw data - take a list of all the questions & answers
                    selected_keys = [
                        "type",
                        "title",
                        "url",
                        "description",
                        "coordinates",
                        "postal_address",
                        "contact",
                        "rating",
                        "distance",
                        "zoom_level",
                    ]
                    cleaned = []
                    for q in results:
                        cleaned.append(
                            {k: v for k, v in q.items() if k in selected_keys}
                        )
                elif r_type == "news":
                    # For faw data - take a list of all the questions & answers
                    selected_keys = [
                        "type",
                        "title",
                        "url",
                        "description",
                    ]
                    cleaned = []
                    for q in results:
                        cleaned.append(
                            {k: v for k, v in q.items() if k in selected_keys}
                        )
                else:
                    cleaned = []

                clean_response.append(cleaned)

        return {"query": query, "top_k": clean_response}


class WolframAlphaTool(SingleMessageBuiltinTool):

    def __init__(self, api_key: str) -> None:
        self.api_key = api_key
        self.url = "https://api.wolframalpha.com/v2/query"

    def get_name(self) -> str:
        return "wolfram_alpha"

    async def run_impl(self, query: str) -> str:
        params = {
            "input": query,
            "appid": self.api_key,
            "format": "plaintext",
            "output": "json",
        }
        response = requests.get(
            self.url,
            params=params,
        )

        return json.dumps(self._clean_wolfram_alpha_response(response.json()))

    def _clean_wolfram_alpha_response(self, wa_response):
        remove = {
            "queryresult": [
                "datatypes",
                "error",
                "timedout",
                "timedoutpods",
                "numpods",
                "timing",
                "parsetiming",
                "parsetimedout",
                "recalculate",
                "id",
                "host",
                "server",
                "related",
                "version",
                {
                    "pods": [
                        "scanner",
                        "id",
                        "error",
                        "expressiontypes",
                        "states",
                        "infos",
                        "position",
                        "numsubpods",
                    ]
                },
                "assumptions",
            ],
        }
        for main_key in remove:
            for key_to_remove in remove[main_key]:
                try:
                    if key_to_remove == "assumptions":
                        if "assumptions" in wa_response[main_key]:
                            del wa_response[main_key][key_to_remove]
                    if isinstance(key_to_remove, dict):
                        for sub_key in key_to_remove:
                            if sub_key == "pods":
                                for i in range(len(wa_response[main_key][sub_key])):
                                    if (
                                        wa_response[main_key][sub_key][i]["title"]
                                        == "Result"
                                    ):
                                        del wa_response[main_key][sub_key][i + 1 :]
                                        break
                            sub_items = wa_response[main_key][sub_key]
                            for i in range(len(sub_items)):
                                for sub_key_to_remove in key_to_remove[sub_key]:
                                    if sub_key_to_remove in sub_items[i]:
                                        del sub_items[i][sub_key_to_remove]
                    elif key_to_remove in wa_response[main_key]:
                        del wa_response[main_key][key_to_remove]
                except KeyError:
                    pass
        return wa_response


class CodeInterpreterTool(BaseTool):

    def __init__(self) -> None:
        ctx = CodeExecutionContext(
            brave_api_key="BSAo9hsA-Gr-d0O-QF65WesoYVqKoRO",
            photogen_api_key="1078097093361062%7CHo16EWDKl2HmOHOEa426PBXVQB8",
            wolfram_api_key="LKRWWW-J25AKURL7T",
            photogen_model="photorealism",
            genai_api_key="780668393902011|4kHo-lmeZGHs_4doSt3t3OjBp_s",
            photogen_dump_dir="/tmp/photogen_dump",
            matplotlib_dump_dir="/tmp/matplotlib_dump",
        )
        self.code_executor = CodeExecutor(ctx)

    def get_name(self) -> str:
        return "code_interpreter"

    async def run(self, messages: List[Message]) -> List[Message]:
        script = "\n".join([m.content for m in messages])

        req = CodeExecutionRequest(scripts=[script])
        res = self.code_executor.execute(req)

        pieces = [res["process_status"]]
        for out_type in ["stdout", "stderr"]:
            res_out = res[out_type]
            if res_out != "":
                pieces.extend([f"[{out_type}]", res_out, f"[/{out_type}]"])
                if out_type == "stderr":
                    cprint(f"ipython tool error: ↓\n{res_out}", color="red")

        message = Message(
            role="ipython",
            content="\n".join(pieces),
        )
        if attachment := interpret_content_as_attachment(res["stdout"]):
            message.content = attachment

        return [message]
