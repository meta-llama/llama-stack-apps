import asyncio
import json
import re
from typing import Dict, List, Optional, Tuple

from .base import BaseTool
from models.llama3.datatypes import Message


BUILTIN_TOOL_PATTERN = r'\b(?P<tool_name>\w+)\.call\(query="(?P<query>[^"]*)"\)'

CUSTOM_TOOL_CALL_PATTERN = re.compile(
    r"<function=(?P<function_name>[^}]+)>(?P<args>{.*?})"
)


class ToolUtils:

    @staticmethod
    def is_builtin_tool_call(message_body: str) -> bool:
        match = re.search(ToolUtils.BUILTIN_TOOL_PATTERN, message_body)
        return match is not None

    @staticmethod
    def maybe_extract_builtin_tool_call(message_body: str) -> Optional[Tuple[str, str]]:
        # Find the first match in the text
        match = re.search(BUILTIN_TOOL_PATTERN, message_body)

        # Check if a match is found and return it
        if match:
            tool_name = match.group("tool_name")
            query = match.group("query")
            return tool_name, query
        else:
            return None

    @staticmethod
    def is_custom_tool_call(message_body: str) -> bool:
        match = re.search(CUSTOM_TOOL_CALL_PATTERN, message_body)
        return match is not None

    @staticmethod
    def maybe_extract_custom_tool_call(message_body: str) -> Optional[Tuple[str, str]]:
        # Find the first match in the text
        match = re.search(CUSTOM_TOOL_CALL_PATTERN, message_body)

        if match:
            tool_name = match.group("function_name")
            query = match.group("args")
            return tool_name, json.loads(query.replace("'", '"'))
        else:
            return None

    @staticmethod
    def execute_tool_call_maybe(
        tools_dict: Dict[str, BaseTool], messages: List[Message]
    ) -> List[Message]:
        # While Tools.run interface takes a list of messages,
        # All tools currently only run on a single message
        # When this changes, we can drop this assert
        # Whether to call tools on each message and aggregate
        # or aggregate and call tool once, reamins to be seen.
        assert len(messages) == 1, "Expected single message"
        message = messages[0]

        # check if builtin tool call
        builtin_tool_info = ToolUtils.maybe_extract_builtin_tool_call(message.content)
        custom_tool_info = ToolUtils.maybe_extract_custom_tool_call(message.content)

        if builtin_tool_info is not None:
            tool_name, _ = builtin_tool_info
        elif custom_tool_info is not None:
            tool_name, _ = custom_tool_info
        elif message.ipython:
            tool_name = "code_interpreter"
        else:
            # No tools and no code execution
            return messages

        tool = tools_dict[tool_name]
        response_messages = asyncio.run(tool.run(messages))
        return response_messages
