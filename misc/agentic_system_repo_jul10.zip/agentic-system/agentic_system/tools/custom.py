import json
import re

from abc import abstractmethod
from dataclasses import dataclass
from typing import Dict, List

from .builtin import BaseTool
from .utils import ToolUtils
from .ipython_tool.code_execution import TOOLS_ATTACHMENT_KEY_REGEX


from models.llama3.datatypes import Message


@dataclass
class FunctionParamDefinition:
    param_type: str
    description: str
    required: bool


class CustomTool(BaseTool):
    """
    Developers can define their custom tools that models can use
    by extending this class.

    Developers need to provide
        - name
        - description
        - params_definition
        - implement tool's behavior in `run_impl` method

    NOTE: The return of the `run` method needs to be json serializable
    """

    @abstractmethod
    def get_description(self) -> str:
        raise NotImplementedError

    @abstractmethod
    def get_params_definition(self) -> Dict[str, FunctionParamDefinition]:
        raise NotImplementedError

    def get_instruction_string(self) -> str:
        return f"Use the function '{self.get_name()}' to: {self.get_description()}"

    def parameters(self) -> str:
        return json.dumps(
            {
                "name": self.get_name(),
                "description": self.get_description(),
                "parameters": {
                    name: definition.__dict__
                    for name, definition in self.get_params_definition().items()
                },
            }
        )


class SingleMessageCustomTool(CustomTool):

    async def run(self, messages: List[Message]) -> List[Message]:
        assert len(messages) == 1, "Expected single message"
        # Extract custom function params from provided message
        tool_info = ToolUtils.maybe_extract_custom_tool_call(messages[0].content)
        assert tool_info is not None, "Expected a custom tool call format"

        _, params = tool_info
        response = await self.run_impl(**params)
        response_str = json.dumps(response)

        message = Message(role="ipython", content=response_str)
        match = re.search(TOOLS_ATTACHMENT_KEY_REGEX, response_str)
        if match:
            snippet = match.group(1)
            data = json.loads(snippet)
            message.attachment = Attachment(**data)

        return [message]

    @abstractmethod
    async def run_impl(self, *args, **kwargs):
        raise NotImplementedError()
