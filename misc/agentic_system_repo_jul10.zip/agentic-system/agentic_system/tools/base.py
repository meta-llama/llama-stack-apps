from abc import ABC, abstractmethod
from typing import List

from models.llama3.datatypes import Message


class BaseTool(ABC):

    @abstractmethod
    def get_name(self) -> str:
        raise NotImplementedError

    @abstractmethod
    async def run(self, messages: List[Message]) -> List[Message]:
        raise NotImplementedError
