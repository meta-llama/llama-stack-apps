import asyncio
from enum import Enum
from typing import List, Optional

from .builtin import BaseTool
from models.llama3.datatypes import Message
from purple_llama.shields import ShieldBase, ShieldRunnerMixin


class SafeTool(BaseTool, ShieldRunnerMixin):
    """A tool that makes other tools safety enabled"""

    def __init__(
        self,
        tool: BaseTool,
        input_shields: List[ShieldBase] = None,
        output_shields: List[ShieldBase] = None
    ):
        self._tool = tool
        ShieldRunnerMixin.__init__(
            self,
            input_shields=input_shields,
            output_shields=output_shields
        )

    def get_name(self) -> str:
        # return the name of the wrapped tool
        return self._tool.get_name()

    async def run(self, messages: List[Message]) -> List[Message]:
        if self.input_shields is not None:
            await self.run_shields(messages, self.input_shields)
        # run the underlying tool
        res = await self._tool.run(messages)
        if self.output_shields is not None:
            await self.run_shields(messages, self.output_shields)

        return res


def with_safety(
    tool: BaseTool,
    input_shields: List[ShieldBase] = None,
    output_shields: List[ShieldBase] = None,
) -> SafeTool:
    return SafeTool(
        tool,
        input_shields=input_shields,
        output_shields=output_shields,
    )
