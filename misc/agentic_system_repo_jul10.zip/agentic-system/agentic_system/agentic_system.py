import concurrent.futures
import logging

from collections import Counter
from datetime import datetime
from termcolor import cprint
from typing import List, Optional

from models.llama3 import Dialog, Message, Attachment
from purple_llama.shields import SafetyException, ShieldBase, ShieldRunnerMixin
from toolchain.inference import ChatPrediction, LlamaModelParallelGenerator

from .tools import BaseTool, CustomTool, ToolUtils


logger = logging.getLogger()
logger.setLevel(logging.INFO)


class AgenticSystem(ShieldRunnerMixin):
    def __init__(
        self,
        generator: LlamaModelParallelGenerator,  # TODO: this should be a simple Generator interface we should import as a type
        tools: List[BaseTool],
        max_seq_len: int,
        input_shields: List[ShieldBase],
        output_shields: List[ShieldBase],
        max_infer_iters: int = 10,
    ):
        self.generator = generator
        self.max_seq_len = max_seq_len
        self.system_prompt = get_agentic_system_prompt(tools)
        self.max_infer_iters = max_infer_iters
        # cprint(self.system_prompt.content, color="green")

        # keep a dict of tools
        ctr = Counter(t.get_name() for t in tools)
        for k, v in ctr.items():
            if v > 1:
                raise ValueError(f"Duplicate tool name: {k}")
        self.tools_dict = {t.get_name(): t for t in tools}

        ShieldRunnerMixin.__init__(
            self,
            input_shields=input_shields,
            output_shields=output_shields,
        )

    async def run(
        self,
        dialog: Dialog,
        temperature: float,
        top_p: float,
        max_gen_len: Optional[int] = None,
    ) -> ChatPrediction:
        try:
            await self.run_shields(dialog, self.input_shields)

            results = self._run_batch([dialog], temperature, top_p, max_gen_len)
            res = results[0]

            # for output shields run on the full input and output combination
            messages = [m for m in dialog] + [res["generation"]]
            await self.run_shields(messages, self.output_shields)

            return res

        except SafetyException as e:
            return {"generation": Message(role="assistant", content=str(e), is_violation=True, eot=True)}

    def _run_batch(
        self,
        dialogs: List[Dialog],
        temperature: float,
        top_p: float,
        max_gen_len: Optional[int] = None,
    ) -> List[ChatPrediction]:
        dialogs = [preprocess_dialog(d, self.system_prompt) for d in dialogs]

        to_process = list(enumerate(dialogs))
        final_results = [None] * len(dialogs)
        attachments = [None] * len(dialogs)

        n_iter = 0
        while len(to_process) > 0:
            batch = [d for _, d in to_process]
            msg = batch[0][-1]
            if msg.role == "user":
                color = "blue"
            elif msg.role == "ipython":
                color = "yellow"
            else:
                color = None
            cprint(f"{str(batch[0][-1])}", color=color)
            current_results = self.generator.chat_completion(
                batch,
                max_gen_len=max_gen_len,
                temperature=temperature,
                top_p=top_p,
            )
            unfinished: List[Tuple[int, Message]] = []
            for (idx, dialog), result in zip(to_process, current_results):
                message = result["generation"]
                if n_iter >= self.max_infer_iters:
                    final_results[idx] = result
                    cprint("Done with MAX iterations, exiting.")
                    break

                # NOTE: When model invokes a custom tool --
                # unfortunately, eot is True and ipython is False
                # Hence, we need to first check if its a custom tool call
                # and if not then rely on eot
                # cprint(f"{str(message)}", color="green")
                if not message.eot or ToolUtils.is_custom_tool_call(
                    message.content
                ):
                    cprint(f"{str(message)}",color="green")
                    unfinished.append((idx, message))
                else:
                    if attachments[idx] is not None:
                        result["generation"].content = [
                            result["generation"].content,
                            attachments[idx],
                        ]
                    final_results[idx] = result

            with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
                futures = {
                    idx: executor.submit(
                        ToolUtils.execute_tool_call_maybe,
                        self.tools_dict,
                        [message],
                    )
                    for idx, message in unfinished
                }
                concurrent.futures.wait(futures.values())

            next_process = []
            for idx, message in unfinished:
                try:
                    result_messages = futures[idx].result()
                    assert (
                        len(result_messages) == 1
                    ), "Currently not supporting multiple messages"
                    result_message = result_messages[0]
                except SafetyException as e:
                    final_results[idx] = {
                        "generation": Message(
                            role="assistant",
                            content=str(e),
                            eot=True,
                        )
                    }
                    continue

                # TODO: handle the Sequence[Union[str, Attachment, Image]] case correctly
                if isinstance(result_message.content, Attachment):
                    # NOTE: when we push this message back to the model, the model may ignore the
                    # attached file path etc. since the model is trained to only provide a user message
                    # with the summary. To keep the attachment around, we store it in an associated array
                    #
                    # right now, this means you can only produce at most one attachment for a user request
                    attachments[idx] = result_message.content

                dialog = to_process[idx][1] + [message, result_message]
                model_input = self.generator.formatter.encode_dialog_prompt(dialog)

                # cprint(f"[debug] next message to be sent to model: {self.generator.tokenizer.decode(tokens)}", color="red")
                if len(model_input.tokens) >= self.max_seq_len:
                    logger.warning(f"Out of token budget for : {dialog[:-1]}")
                    final_results[idx] = {
                        "generation": message,
                    }
                else:
                    next_process.append((idx, dialog))

            to_process = next_process

            n_iter += 1

        return final_results


def get_agentic_system_prompt(tools) -> Message:
    current_date = datetime.now()
    formatted_date = current_date.strftime("%d %B %Y")
    content = f"""
Environment: ipython
Tools: brave_search, photogen, wolfram_alpha

Cutting Knowledge Date: 01 March 2023
Today's Date: {formatted_date}

# Tool Instructions
- Always execute python code in messages that you share.
- When looking for real time information use relevant functions if available else fallback to brave_search
    """

    custom_tool_params = ""
    for t in tools:
        if isinstance(t, CustomTool):
            custom_tool_params += t.get_instruction_string() + "\n"
            custom_tool_params += t.parameters() + "\n\n"

    # If a you choose to call a function ONLY reply with the tag '<function={{function_name}}>{{parameters}}</function>'
    # parameters is a JSON dict with the function argument name as key and function argument value as value.
    if custom_tool_params != "":
        custom_tool_message = f"""
You have access to the following functions:

{custom_tool_params}
If a you choose to call a function ONLY reply in the following format:
<{{start_tag}}={{function_name}}>{{parameters}}{{end_tag}}
where

start_tag => `<function`
parameters => a JSON dict with the function argument name as key and function argument value as value.
end_tag => `</function>`

Here is an example,
<function=example_function_name>{{"example_name": "example_value"}}</function>

Reminder:
- Function calls MUST follow the specified format
- Required parameters MUST be specified
- Only call one function at a time
- Put the entire function call reply on one line"

You are a helpful Assistant."""
        content += "\n\n" + custom_tool_message

    return Message(role="system", content=content)


def attachment_message(filepath: str) -> Message:
    return Message(
        role="user",
        ipython=True,
        content=f'# There is a file accessible to you at "{filepath}"',
    )

def preprocess_dialog(dialog: Dialog, system_prompt: Message) -> Dialog:
    """
    Preprocesses the dialog by removing the system message and
    adding the system message to the beginning of the dialog.
    """
    ret = [system_prompt]
    for m in dialog:
        if m.role == "system":
            continue

        # NOTE: the ideal behavior is to use `file_path = ...` but that
        # means we need to have stateful execution of code which we currently
        # do not have.
        if isinstance(m.content, Attachment):
            ret.append(attachment_message(c.filepath))
        elif isinstance(m.content, list):
            for x in m.content:
                if isinstance(x, Attachment):
                    ret.append(attachment_message(x.filepath))
        
        ret.append(m)

    return ret
