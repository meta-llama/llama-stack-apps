import json 

from dataclasses import dataclass
from functools import partial
from typing import List, Optional

from models.llama3.mock_generation import *  # noqa
from models.llama3.args import ModelArgs
from models.llama3.tokenizer import ChatFormat, Dialog, Tokenizer
from pathlib import Path
from toolchain.inference.parallel_utils import ModelParallelProcessGroup
from toolchain.inference.generation import ChatPrediction, Llama, GeneratorArgs

@dataclass
class InferenceArgs:
    dialogs: List[Dialog]
    temperature: float
    top_p: float
    max_gen_len: int
    logprobs: bool


class ModelRunner:
    def __init__(self, llama):
        self.llama = llama

    # the `task` object is the same that is sent to `ModelParallelProcessGroup.run_inference()`
    def __call__(self, task: InferenceArgs):
        return self.llama.chat_completion(
            task.dialogs,
            task.temperature,
            task.top_p,
            task.max_gen_len,
            task.logprobs,
        )


def init_model_cb(args: GeneratorArgs):
    if args.mock_generation:
        llama = MockToolLlama(args.tokenizer_path, mock_unsafe_brave())
    else:
        llama = Llama.build(
            args.ckpt_dir,
            args.tokenizer_path,
            args.max_seq_len,
            args.max_batch_size,
        )
    return ModelRunner(llama)


class LlamaModelParallelGenerator:
    """
    This abstraction exists so
     - we can run model parallel code without needing to run the CLIs via torchrun
     - this also enables use model parallel code within a notebook context.

    A Context Manager is used to ensure that the model parallel process is started and stopped
    correctly. This does make the ergonomics a little awkward, because it isn't immediately
    clear at the callsite why we need to use a context manager.
    """

    def __init__(self, args: GeneratorArgs):
        self.args = args

        # params = Path(self.args.ckpt_dir) / "params.json"
        # with open(params) as f:
        #     params = json.load(f)
        
        # model_args = ModelArgs(**params)

        # this is a hack because Agent's loop uses this to tokenize and check if input is too long
        # while the tool-use loop is going
        self.formatter = ChatFormat(Tokenizer(self.args.tokenizer_path))

    def start(self):
        self.__enter__()

    def stop(self):
        self.__exit__(None, None, None)

    def __enter__(self):
        self.group = ModelParallelProcessGroup(
            self.args.model_parallel_size,
            init_model_cb=partial(init_model_cb, self.args),
        )
        self.group.start()
        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):
        self.group.stop()

    def chat_completion(
        self,
        dialogs: List[Dialog],
        temperature: float = 0.6,
        top_p: float = 0.9,
        max_gen_len: Optional[int] = None,
        logprobs: bool = False,
    ) -> List[ChatPrediction]:
        req_obj = InferenceArgs(
            dialogs=dialogs,
            temperature=temperature,
            top_p=top_p,
            max_gen_len=max_gen_len,
            logprobs=logprobs,
        )
        resp = self.group.run_inference(req_obj)
        if isinstance(resp, Exception):
            print(f"Exception while executing req: {resp}")
            raise resp

        return resp
