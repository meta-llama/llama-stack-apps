
The architecture of the system is here: https://www.internalfb.com/excalidraw/EX226110

The sequence diagram with more details of the communication between components is below:

```mermaid
sequenceDiagram
    participant U as User
    participant S as Shields
    participant E as Executor
    participant L as LLM
    participant T as Tool
    U->>E: User prompt
    E->>S: Filter/transform via prompt shields
    S->>E: Submit prompts to executor
    E->>L: Prompt with available tools
    L->>E: LLM response with tools to be called
    E->>S: Filter/transform tool call code via code/cybersec shields
    S->>E: Receive shield response
    E->>T: Call tool
    T->>E: Receive tool response
    E->>S: Filter/transform tool response
    S->>E: Receive shield response
    E->>L: Prompt with tool response
    L->>E: LLM response with synthesized tool response
    E->>S: Filter/transform final user response
    S->>E: Receive final shield response
    E->>U: User response
```
